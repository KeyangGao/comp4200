package com.example.librarymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

public class usermanage extends AppCompatActivity {

    Button btn_search, btn_add,btn_delete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usermanage);

        //btn_add=findViewById(R.id.)
    }
}