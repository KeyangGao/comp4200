package com.example.bookinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class admin_return_info extends AppCompatActivity {
    private ListView ad_pay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_return_info);

        ad_pay=(ListView)findViewById(R.id.ad_show_pay);
        databaseHelp help=new databaseHelp(getApplicationContext());
        List<Map<String, Object>> data = help.queryreturn();
        SimpleAdapter adapter = new SimpleAdapter(
                admin_return_info.this, data, R.layout.activity_ad_pay_item,
                new String[] {  "_Rid","Borname","Bookid", "bookname", "nowtime" },
                new int[] { R.id.ad_pid ,R.id.ad_puname,
                        R.id.ad_ppid, R.id.ad_pnbame,
                        R.id.ad_ptime });
        ad_pay.setAdapter(adapter);

    }
}