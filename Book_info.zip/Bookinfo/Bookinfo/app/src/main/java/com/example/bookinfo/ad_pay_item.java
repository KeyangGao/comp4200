package com.example.bookinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ad_pay_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_pay_item);
    }
}