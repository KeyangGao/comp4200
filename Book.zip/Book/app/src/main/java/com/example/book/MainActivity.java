package com.example.book;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    private ImageButton book_info_bt, borrow_bt, return_bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init() {
        book_info_bt = (ImageButton) findViewById(R.id.ad_select_bookinfo);
        book_info_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, admin_select_bookinfo.class);
                startActivity(intent);
            }
        });

        borrow_bt = (ImageButton) findViewById(R.id.ad_select_brrow);
        borrow_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, admin_borrow_info.class);
                startActivity(intent);
            }
        });

        return_bt = (ImageButton) findViewById(R.id.ad_manager_reader);
        return_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, admin_return_info.class);
                startActivity(intent);
            }
        });
    }
}