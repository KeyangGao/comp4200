package com.example.book;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class admin_update_book extends AppCompatActivity {
    private Button add_book_bt;
    private String str;

    private int id;
    private databaseHelp helper;
    Uri uri;
    private EditText et_bookid,et_bookname,et_booktype,et_bookwriter,et_bookpublicer,et_bookprice,et_bookrank,et_bookcomment;
    private Button btn_bookcommit,btn_bookback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update_book);
        initdata();
        helper = new databaseHelp(getApplicationContext());
    }
    private void initdata() {
        Bundle bundle = getIntent().getExtras();
        id = bundle.getInt("id")+1 ;
        Log.i("cursor", "initiated: " + id);


        et_bookid=findViewById(R.id.et_bookid);
        et_bookname=findViewById(R.id.et_bookname);
        et_booktype=findViewById(R.id.et_booktype);
        et_bookwriter=findViewById(R.id.et_bookwriter);
        et_bookpublicer=findViewById(R.id.et_bookpublicer);
        et_bookprice=findViewById(R.id.et_bookprice);
        et_bookrank=findViewById(R.id.et_bookrank);
        et_bookcomment=findViewById(R.id.et_bookcomment);


        btn_bookcommit=findViewById(R.id.btn_bookcommit);
        btn_bookback=findViewById(R.id.btn_bookback);

        final databaseHelp help = new databaseHelp(getApplicationContext());
        Cursor cursor = help.querybookinfoid(id);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            et_bookid.setText(cursor.getString(cursor.getColumnIndex("bookid")));
            et_bookname.setText(cursor.getString(cursor.getColumnIndex("name")));
            et_bookwriter.setText(cursor.getString(cursor.getColumnIndex("writer")));
            et_booktype.setText(cursor.getString(cursor.getColumnIndex("type")));
            et_bookprice.setText(cursor.getString(cursor.getColumnIndex("price")));
            et_bookpublicer.setText(cursor.getString(cursor.getColumnIndex("publicer")));
            et_bookcomment.setText(cursor.getString(cursor.getColumnIndex("comment")));
            et_bookrank.setText(cursor.getString(cursor.getColumnIndex("rank")));
        }

        btn_bookcommit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_update_book.this, admin_select_bookinfo.class);
                startActivity(intent);
            }
        });


    }
}